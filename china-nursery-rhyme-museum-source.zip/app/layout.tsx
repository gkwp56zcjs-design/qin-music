import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "中国儿歌数字博物馆",
  description: "听见中国童谣的故事，探索地域儿歌、世界经典与参观者共创作品。",
  icons: {
    icon: "/favicon.svg",
    shortcut: "/favicon.svg",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="zh-CN">
      <body className="antialiased">{children}</body>
    </html>
  );
}
