import { getChatGPTUser } from "./chatgpt-auth";
import Museum from "./museum";
export const dynamic = "force-dynamic";
export default async function Home(){const user=await getChatGPTUser();return <Museum userName={user?.displayName??"小小参观者"} signedIn={Boolean(user)}/>}
