# 中国儿歌数字博物馆｜源码部署说明

## 包含内容

- 中国地域儿歌馆藏与故事导览
- 可使用方向键或页面按钮移动的“小童”角色
- “你唱一句、馆长接一句”互动流程
- 世界经典儿歌展厅
- 参观者作品墙、作品投稿表单与留言板
- PDF、MP3、MOV、MP4、PNG、JPG 等资源类型入口
- D1/SQLite 数据表定义与迁移文件
- 桌面端和移动端响应式布局

## 本地运行

需要 Node.js 22 或更高版本。

```bash
npm install
npm run dev
```

开发服务器启动后，按照终端显示的地址访问。

## 生产构建

```bash
npm install
npm run build
```

构建结果位于 `dist/`。

## 部署建议

### Vercel

将源码上传至 GitHub 后在 Vercel 导入仓库。构建命令填写 `npm run build`。当前项目使用面向 Cloudflare Worker 的 Vinext 输出，因此若需完整使用留言数据和文件存储，建议改用支持 Cloudflare Worker/D1/R2 的运行环境；也可以将留言与投稿接口替换成 Vercel Functions 和数据库服务。

### GitHub Pages

GitHub Pages 只支持静态文件。视觉界面和浏览器端互动可以保留，但留言持久化、登录身份和文件上传需要改接独立 API。部署前请将首页改为纯静态入口，并把构建产物发布到 `gh-pages` 分支。

### 阿里云或腾讯云

推荐使用 Node.js 22 容器或云函数。执行 `npm install`、`npm run build`，再运行项目的生产入口。留言数据可迁移到 MySQL/PostgreSQL，文件资源可分别存放到阿里云 OSS 或腾讯云 COS。

### Cloudflare Workers

这是当前源码支持最完整的部署方式。数据库绑定名称为 `DB`，对象存储绑定名称为 `BUCKET`。发布前应用 `drizzle/` 中的数据库迁移文件。

## 正式上线前需要完成

1. 将示范馆藏替换为经过核实且拥有使用授权的儿歌资料。
2. 将馆藏卡片中的 PDF、音频、视频与图片占位入口替换为真实资源地址。
3. 为参观者投稿增加服务端文件上传、内容审核和版权确认流程。
4. 接入浏览器录音与语音识别服务，实现真正的自动接唱与节奏判断。
5. 儿童用户发布内容时，增加监护人同意、隐私提示和敏感信息过滤。

## 主要文件

- `app/museum.tsx`：博物馆内容和交互
- `app/globals.css`：视觉样式与响应式布局
- `app/api/messages/route.ts`：留言接口
- `db/schema.ts`：留言和投稿数据结构
- `drizzle/`：数据库迁移
- `public/favicon.svg`：网站图标

